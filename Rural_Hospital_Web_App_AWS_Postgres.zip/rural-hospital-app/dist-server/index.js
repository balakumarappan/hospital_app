// server/index.ts
import express from "express";
import cookieParser from "cookie-parser";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { parse } from "csv-parse/sync";
import { SNSClient, PublishCommand } from "@aws-sdk/client-sns";
import QRCode from "qrcode";
import { randomInt } from "node:crypto";
import { join } from "node:path";

// server/db.ts
import "dotenv/config";
import pg from "pg";
var db = new pg.Pool({ connectionString: process.env.DATABASE_URL, max: 10, ssl: process.env.DATABASE_SSL === "true" ? { rejectUnauthorized: true } : void 0 });
async function transaction(fn) {
  const c = await db.connect();
  try {
    await c.query("BEGIN");
    const result = await fn(c);
    await c.query("COMMIT");
    return result;
  } catch (e) {
    await c.query("ROLLBACK");
    throw e;
  } finally {
    c.release();
  }
}

// server/schedule.ts
function validDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = /* @__PURE__ */ new Date(value + "T12:00:00Z");
  return !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === value;
}
function todayIndia() {
  return new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Kolkata", year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date());
}
function visits(d, date) {
  if (!d.active || !validDate(date)) return false;
  const dt = /* @__PURE__ */ new Date(date + "T12:00:00Z");
  return d.pattern === "daily" || d.pattern === "weekly" && d.weekdays.includes(dt.getUTCDay()) || d.pattern === "monthly" && d.month_day === dt.getUTCDate();
}
function minutes(time) {
  const [h, m] = time.slice(0, 5).split(":").map(Number);
  return h * 60 + m;
}
function slots(d) {
  const out = [];
  for (let i = minutes(d.start_time); i + d.slot_minutes <= minutes(d.end_time); i += d.slot_minutes) out.push(`${String(Math.floor(i / 60)).padStart(2, "0")}:${String(i % 60).padStart(2, "0")}`);
  return out;
}
function withinWindow(date) {
  if (!validDate(date)) return false;
  const days = (Date.parse(date + "T12:00:00Z") - Date.parse(todayIndia() + "T12:00:00Z")) / 864e5;
  return days >= 0 && days <= 62;
}

// server/index.ts
var app = express();
app.disable("x-powered-by");
app.use(express.json({ limit: "2mb" }));
app.use(cookieParser());
var secret = process.env.SESSION_SECRET;
if (!secret || secret.length < 32) throw new Error("SESSION_SECRET must contain at least 32 characters");
var prod = process.env.NODE_ENV === "production";
function fail(status, message) {
  throw Object.assign(new Error(message), { status });
}
function auth(req, res, next) {
  try {
    const token = req.cookies.hospital_session;
    if (!token) fail(401, "Please sign in first");
    req.session = jwt.verify(token, secret);
    next();
  } catch {
    res.status(401).json({ error: "Please sign in first" });
  }
}
function allow(kind, role) {
  return (req, res, next) => {
    const s = req.session;
    if (s.kind !== kind || role && s.role !== role) {
      res.status(403).json({ error: "Access denied" });
      return;
    }
    next();
  };
}
function cookie(res, s) {
  res.cookie("hospital_session", jwt.sign(s, secret, { expiresIn: kindExpiry(s) }), { httpOnly: true, sameSite: "lax", secure: prod, maxAge: kindExpiry(s) * 1e3, path: "/" });
}
function kindExpiry(s) {
  return s.kind === "patient" ? 3600 : 8 * 3600;
}
app.use("/api", (req, res, next) => {
  if (["POST", "PUT", "PATCH", "DELETE"].includes(req.method)) {
    const origin = req.get("origin");
    const host = req.get("host");
    if (origin) {
      try {
        const url = new URL(origin);
        const allowed = process.env.PUBLIC_ORIGIN ? url.origin === process.env.PUBLIC_ORIGIN : !prod && ["localhost", "127.0.0.1"].includes(url.hostname);
        if (!allowed || prod && url.host !== host) {
          res.status(403).json({ error: "Invalid origin" });
          return;
        }
      } catch {
        res.status(403).json({ error: "Invalid origin" });
        return;
      }
    }
    if (!req.is("application/json")) {
      res.status(415).json({ error: "JSON required" });
      return;
    }
  }
  next();
});
var post = (path, ...handlers) => app.post("/api" + path, ...handlers);
var get = (path, ...handlers) => app.get("/api" + path, ...handlers);
var put = (path, ...handlers) => app.put("/api" + path, ...handlers);
function mobile(v) {
  const s = String(v ?? "").trim();
  if (!/^[6-9]\d{9}$/.test(s)) fail(400, "Enter a valid 10-digit mobile number");
  return s;
}
function uuid(v) {
  const s = String(v ?? "");
  if (!/^[0-9a-f]{8}-[0-9a-f-]{27,}$/.test(s)) fail(400, "Invalid identifier");
  return s;
}
function text(v, max = 120) {
  const s = String(v ?? "").trim();
  if (!s || s.length > max) fail(400, "Please complete the required fields");
  return s;
}
function patientInput(body) {
  const full_name = text(body.full_name), village = text(body.village, 180), sex = text(body.sex, 20);
  if (!["Female", "Male", "Other", "Prefer not to say"].includes(sex)) fail(400, "Select sex");
  const dob = body.dob ? String(body.dob) : null, age_years = body.age_years !== "" && body.age_years != null ? Number(body.age_years) : null;
  if (dob && (!validDate(dob) || dob > (/* @__PURE__ */ new Date()).toISOString().slice(0, 10))) fail(400, "Invalid date of birth");
  if (age_years !== null && (!Number.isInteger(age_years) || age_years < 0 || age_years > 125)) fail(400, "Invalid age");
  if (!dob && age_years === null) fail(400, "Enter age or date of birth");
  return { full_name, village, sex, dob, age_years };
}
async function sendOtp(number, code) {
  if (process.env.SMS_PROVIDER === "aws") {
    const client = new SNSClient({ region: process.env.AWS_REGION || "ap-south-1" });
    await client.send(new PublishCommand({ PhoneNumber: "+91" + number, Message: `Your hospital verification code is ${code}. It expires in 5 minutes.`, MessageAttributes: { "AWS.SNS.SMS.SMSType": { DataType: "String", StringValue: "Transactional" }, ...process.env.SMS_SENDER_ID ? { "AWS.SNS.SMS.SenderID": { DataType: "String", StringValue: process.env.SMS_SENDER_ID } } : {} } }));
    return;
  }
  if (!prod && process.env.SMS_PROVIDER === "console") {
    console.log(`Local OTP for ${number}: ${code}`);
    return;
  }
  fail(503, "SMS is not configured");
}
get("/health", async (_req, res) => {
  await db.query("SELECT 1");
  res.json({ status: "ok" });
});
get("/admin/qr", auth, allow("staff", "admin"), async (_req, res) => {
  const url = process.env.PUBLIC_ORIGIN || (!prod ? "http://localhost:5173" : "");
  if (!url) fail(503, "Set PUBLIC_ORIGIN before generating the patient QR code");
  const svg = await QRCode.toString(url + "/", { type: "svg", margin: 2, color: { dark: "#135267", light: "#FFFFFF" } });
  res.setHeader("Cache-Control", "no-store");
  res.type("image/svg+xml").send(svg);
});
get("/session", auth, (req, res) => res.json(req.session));
post("/logout", (_req, res) => {
  res.clearCookie("hospital_session", { path: "/" });
  res.json({ ok: true });
});
post("/auth/otp/request", async (req, res) => {
  const number = mobile(req.body.mobile);
  const old = await db.query("SELECT last_sent_at FROM otp_challenges WHERE mobile=$1", [number]);
  if (old.rows[0] && Date.now() - new Date(old.rows[0].last_sent_at).getTime() < 6e4) fail(429, "Wait one minute before requesting another code");
  const code = String(randomInt(1e5, 1e6));
  await sendOtp(number, code);
  await db.query("INSERT INTO otp_challenges(mobile,code_hash,expires_at,last_sent_at,attempts) VALUES($1,$2,now()+interval '5 minutes',now(),0) ON CONFLICT(mobile) DO UPDATE SET code_hash=$2,expires_at=now()+interval '5 minutes',last_sent_at=now(),attempts=0", [number, await bcrypt.hash(code, 10)]);
  res.json({ ok: true });
});
post("/auth/otp/verify", async (req, res) => {
  const number = mobile(req.body.mobile), code = String(req.body.code ?? "");
  const c = await db.query("SELECT * FROM otp_challenges WHERE mobile=$1", [number]);
  const row = c.rows[0];
  if (!row || row.attempts >= 5 || new Date(row.expires_at).getTime() < Date.now()) fail(400, "Code invalid or expired");
  await db.query("UPDATE otp_challenges SET attempts=attempts+1 WHERE mobile=$1", [number]);
  if (!/^\d{6}$/.test(code) || !await bcrypt.compare(code, row.code_hash)) fail(400, "Code invalid or expired");
  await db.query("DELETE FROM otp_challenges WHERE mobile=$1", [number]);
  cookie(res, { kind: "patient", mobile: number });
  res.json({ ok: true });
});
post("/auth/staff", async (req, res) => {
  const username = text(req.body.username, 80), password = String(req.body.password ?? "");
  const q = await db.query("SELECT * FROM staff WHERE username=$1 AND active=true", [username]);
  const row = q.rows[0];
  if (!row || !await bcrypt.compare(password, row.password_hash)) fail(401, "Invalid login");
  cookie(res, { kind: "staff", id: row.id, role: row.role, name: row.name });
  res.json({ kind: "staff", id: row.id, role: row.role, name: row.name });
});
get("/doctors", async (_req, res) => {
  const q = await db.query("SELECT * FROM doctors WHERE active=true ORDER BY specialty,full_name");
  res.json(q.rows);
});
get("/doctors/:id/slots", async (req, res) => {
  const id = uuid(req.params.id), date = String(req.query.date ?? "");
  if (!withinWindow(date)) fail(400, "Select a date in the next 62 days");
  const q = await db.query("SELECT * FROM doctors WHERE id=$1 AND active=true", [id]);
  const d = q.rows[0];
  if (!d) fail(404, "Doctor unavailable");
  const leave = await db.query("SELECT 1 FROM doctor_leave WHERE doctor_id=$1 AND on_date=$2", [id, date]);
  if (!visits(d, date) || leave.rowCount) {
    res.json({ date, slots: [] });
    return;
  }
  const taken = await db.query("SELECT at_time::text AS time,count(*)::int AS taken FROM appointments WHERE doctor_id=$1 AND on_date=$2 AND status='booked' GROUP BY at_time", [id, date]);
  const counts = new Map(taken.rows.map((x) => [x.time.slice(0, 5), x.taken]));
  res.json({ date, slots: slots(d).map((time) => ({ time, remaining: d.capacity - (counts.get(time) || 0) })) });
});
async function accessiblePatient(req, patientId) {
  const s = req.session;
  if (s.kind === "staff") return;
  const q = await db.query("SELECT 1 FROM patient_phones WHERE patient_id=$1 AND mobile=$2", [patientId, s.mobile]);
  if (!q.rowCount) fail(403, "Patient profile not linked to this mobile");
}
get("/patients", auth, allow("patient"), async (req, res) => {
  const s = req.session;
  const q = await db.query("SELECT p.id,p.uhid,p.full_name,p.dob,p.age_years,p.sex,p.village FROM patients p JOIN patient_phones ph ON ph.patient_id=p.id WHERE ph.mobile=$1 ORDER BY p.full_name", [s.mobile]);
  res.json(q.rows);
});
post("/patients", auth, async (req, res) => {
  const s = req.session;
  if (s.kind === "staff" && !req.body.identity_confirmed) fail(400, "Confirm identity before registering");
  const data = patientInput(req.body), number = s.kind === "patient" ? s.mobile : req.body.mobile ? mobile(req.body.mobile) : null;
  if (!number && s.role !== "admin") fail(403, "Only an administrator can register without a mobile number");
  const result = await transaction(async (c) => {
    const dupe = await c.query("SELECT uhid FROM patients WHERE lower(full_name)=lower($1) AND lower(village)=lower($4) AND (dob=$2::date OR ($2::date IS NULL AND age_years=$3)) LIMIT 1", [data.full_name, data.dob, data.age_years, data.village]);
    if (dupe.rowCount) fail(409, "Possible existing patient. Ask reception to check the UHID before creating another record.");
    const p = await c.query("INSERT INTO patients(uhid,full_name,dob,age_years,sex,village) VALUES('RH-'||lpad(nextval('uhid_seq')::text,6,'0'),$1,$2,$3,$4,$5) RETURNING *", [data.full_name, data.dob, data.age_years, data.sex, data.village]);
    if (number) await c.query("INSERT INTO patient_phones(patient_id,mobile) VALUES($1,$2)", [p.rows[0].id, number]);
    return p.rows[0];
  });
  res.status(201).json(result);
});
get("/staff/patients", auth, allow("staff"), async (req, res) => {
  const q = text(req.query.q, 120);
  const result = await db.query("SELECT p.id,p.uhid,p.full_name,p.dob,p.age_years,p.sex,p.village,coalesce(string_agg(ph.mobile,', '),'') AS mobiles FROM patients p LEFT JOIN patient_phones ph ON ph.patient_id=p.id WHERE p.uhid ILIKE $1 OR p.full_name ILIKE $1 OR ph.mobile=$2 GROUP BY p.id ORDER BY p.full_name LIMIT 30", ["%" + q + "%", q]);
  res.json(result.rows);
});
put("/staff/patients/:id/mobile", auth, allow("staff"), async (req, res) => {
  const patientId = uuid(req.params.id), number = mobile(req.body.mobile), action = String(req.body.action || "");
  if (!req.body.identity_confirmed) fail(400, "Confirm the patient or caregiver identity first");
  if (!["link", "replace"].includes(action)) fail(400, "Choose link or replace");
  await transaction(async (c) => {
    const p = await c.query("SELECT id FROM patients WHERE id=$1 FOR UPDATE", [patientId]);
    if (!p.rowCount) fail(404, "Patient not found");
    if (action === "replace") await c.query("DELETE FROM patient_phones WHERE patient_id=$1", [patientId]);
    await c.query("INSERT INTO patient_phones(patient_id,mobile) VALUES($1,$2) ON CONFLICT DO NOTHING", [patientId, number]);
  });
  res.json({ ok: true });
});
async function reserve(c, doctorId, date, time, excludeId) {
  if (!withinWindow(date)) fail(400, "Select a date in the next 62 days");
  const q = await c.query("SELECT * FROM doctors WHERE id=$1 AND active=true", [doctorId]);
  const d = q.rows[0];
  if (!d || !visits(d, date) || !slots(d).includes(time)) fail(400, "Doctor does not consult at this time");
  const leave = await c.query("SELECT 1 FROM doctor_leave WHERE doctor_id=$1 AND on_date=$2", [doctorId, date]);
  if (leave.rowCount) fail(409, "Doctor is unavailable on this date");
  await c.query("SELECT pg_advisory_xact_lock(hashtext($1),hashtext($2))", [doctorId, date + "|" + time]);
  const count = await c.query("SELECT count(*)::int AS n FROM appointments WHERE doctor_id=$1 AND on_date=$2 AND at_time=$3 AND status='booked' AND id IS DISTINCT FROM $4::uuid", [doctorId, date, time, excludeId || null]);
  if (count.rows[0].n >= d.capacity) fail(409, "This slot has just filled. Please choose another.");
}
get("/appointments", auth, async (req, res) => {
  const s = req.session;
  const where = s.kind === "patient" ? "WHERE ph.mobile=$1" : "WHERE a.on_date >= current_date - 7";
  const params = s.kind === "patient" ? [s.mobile] : [];
  const q = await db.query(`SELECT a.id,a.reference,a.patient_id,a.doctor_id,a.on_date::text,a.at_time::text,a.status,p.uhid,p.full_name AS patient_name,d.full_name AS doctor_name,d.specialty FROM appointments a JOIN patients p ON a.patient_id=p.id JOIN doctors d ON a.doctor_id=d.id LEFT JOIN patient_phones ph ON ph.patient_id=p.id ${where} GROUP BY a.id,p.id,d.id ORDER BY a.on_date DESC,a.at_time DESC LIMIT 200`, params);
  res.json(q.rows);
});
post("/appointments", auth, async (req, res) => {
  const patientId = uuid(req.body.patient_id), doctorId = uuid(req.body.doctor_id), date = String(req.body.date || ""), time = String(req.body.time || "");
  await accessiblePatient(req, patientId);
  const s = req.session;
  if (s.kind === "staff" && !req.body.identity_confirmed) fail(400, "Confirm patient identity before booking");
  const result = await transaction(async (c) => {
    await reserve(c, doctorId, date, time);
    const q = await c.query("INSERT INTO appointments(reference,patient_id,doctor_id,on_date,at_time,booked_by) VALUES('APT-'||lpad(nextval('appointment_seq')::text,6,'0'),$1,$2,$3,$4,$5) RETURNING *", [patientId, doctorId, date, time, s.kind === "staff" ? s.id : null]);
    return q.rows[0];
  });
  res.status(201).json(result);
});
put("/appointments/:id", auth, async (req, res) => {
  const id = uuid(req.params.id);
  const result = await transaction(async (c) => {
    const q = await c.query("SELECT * FROM appointments WHERE id=$1 FOR UPDATE", [id]);
    const a = q.rows[0];
    if (!a) fail(404, "Appointment not found");
    await accessiblePatient(req, a.patient_id);
    if (a.status !== "booked") fail(409, "Appointment is already cancelled");
    if (req.body.action === "cancel") {
      await c.query("UPDATE appointments SET status='cancelled',updated_at=now() WHERE id=$1", [id]);
      return { ok: true };
    }
    if (req.body.action !== "move") fail(400, "Invalid action");
    const doctorId = uuid(req.body.doctor_id || a.doctor_id), date = String(req.body.date || ""), time = String(req.body.time || "");
    await reserve(c, doctorId, date, time, id);
    await c.query("UPDATE appointments SET doctor_id=$2,on_date=$3,at_time=$4,updated_at=now() WHERE id=$1", [id, doctorId, date, time]);
    return { ok: true };
  });
  res.json(result);
});
function doctorInput(b) {
  const full_name = text(b.full_name), specialty = text(b.specialty), pattern = text(b.pattern, 10);
  if (!["daily", "weekly", "monthly"].includes(pattern)) fail(400, "Choose a visit pattern");
  const weekdays = Array.isArray(b.weekdays) ? b.weekdays.map(Number) : [], month_day = b.month_day ? Number(b.month_day) : null, slot_minutes = Number(b.slot_minutes), capacity = Number(b.capacity), start_time = String(b.start_time || ""), end_time = String(b.end_time || "");
  if (pattern === "weekly" && (!weekdays.length || weekdays.some((x) => !Number.isInteger(x) || x < 0 || x > 6))) fail(400, "Select weekdays");
  if (pattern === "monthly" && (!Number.isInteger(month_day) || month_day < 1 || month_day > 31)) fail(400, "Select a day from 1 to 31");
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(start_time) || !/^([01]\d|2[0-3]):[0-5]\d$/.test(end_time) || start_time >= end_time || !Number.isInteger(slot_minutes) || slot_minutes < 5 || slot_minutes > 120 || !Number.isInteger(capacity) || capacity < 1 || capacity > 50) fail(400, "Check consultation hours and capacity");
  return { full_name, specialty, pattern, weekdays, month_day, start_time, end_time, slot_minutes, capacity };
}
post("/admin/doctors", auth, allow("staff", "admin"), async (req, res) => {
  const d = doctorInput(req.body);
  const q = await db.query("INSERT INTO doctors(full_name,specialty,pattern,weekdays,month_day,start_time,end_time,slot_minutes,capacity) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *", Object.values(d));
  res.status(201).json(q.rows[0]);
});
put("/admin/doctors/:id", auth, allow("staff", "admin"), async (req, res) => {
  const id = uuid(req.params.id), d = doctorInput(req.body);
  const q = await db.query("UPDATE doctors SET full_name=$2,specialty=$3,pattern=$4,weekdays=$5,month_day=$6,start_time=$7,end_time=$8,slot_minutes=$9,capacity=$10 WHERE id=$1 RETURNING *", [id, ...Object.values(d)]);
  if (!q.rowCount) fail(404, "Doctor not found");
  res.json(q.rows[0]);
});
get("/admin/doctors", auth, allow("staff", "admin"), async (_req, res) => {
  const q = await db.query("SELECT d.*,coalesce(json_agg(json_build_object('date',l.on_date,'reason',l.reason)) FILTER(WHERE l.on_date IS NOT NULL),'[]') AS leave FROM doctors d LEFT JOIN doctor_leave l ON l.doctor_id=d.id GROUP BY d.id ORDER BY d.full_name");
  res.json(q.rows);
});
post("/admin/doctors/:id/leave", auth, allow("staff", "admin"), async (req, res) => {
  const id = uuid(req.params.id), date = String(req.body.date || "");
  if (!validDate(date)) fail(400, "Invalid date");
  await db.query("INSERT INTO doctor_leave(doctor_id,on_date,reason) VALUES($1,$2,$3) ON CONFLICT(doctor_id,on_date) DO UPDATE SET reason=$3", [id, date, String(req.body.reason || "")]);
  res.json({ ok: true });
});
get("/staff/affected", auth, allow("staff"), async (_req, res) => {
  const q = await db.query("SELECT a.id,a.reference,a.on_date::text,a.at_time::text,p.full_name AS patient_name,d.full_name AS doctor_name,d.pattern,d.weekdays,d.month_day,d.start_time::text,d.end_time::text,d.slot_minutes,d.capacity,d.active,count(*) OVER (PARTITION BY a.doctor_id,a.on_date,a.at_time)::int AS occupied,EXISTS(SELECT 1 FROM doctor_leave l WHERE l.doctor_id=a.doctor_id AND l.on_date=a.on_date) AS on_leave FROM appointments a JOIN doctors d ON d.id=a.doctor_id JOIN patients p ON p.id=a.patient_id WHERE a.status='booked' AND a.on_date>=current_date ORDER BY a.on_date LIMIT 500");
  res.json(q.rows.filter((a) => a.on_leave || !visits(a, a.on_date) || !slots(a).includes(a.at_time.slice(0, 5)) || a.occupied > a.capacity));
});
post("/admin/import", auth, allow("staff", "admin"), async (req, res) => {
  const csv = text(req.body.csv, 15e5), commit = req.body.commit === true;
  let records;
  try {
    records = parse(csv, { columns: true, skip_empty_lines: true, trim: true, bom: true });
  } catch {
    fail(400, "Invalid CSV file");
  }
  if (records.length > 5e3) fail(400, "Import up to 5,000 rows at a time");
  const issues = [], seen = /* @__PURE__ */ new Set();
  const rows = records.map((r, i) => {
    try {
      const uhid = text(r.uhid, 40);
      if (seen.has(uhid)) issues.push(`Row ${i + 2}: duplicate UHID in file`);
      seen.add(uhid);
      const data = patientInput({ full_name: r.full_name, dob: r.dob, age_years: r.age_years, sex: r.sex, village: r.village });
      const phone = r.mobile ? mobile(r.mobile) : null;
      return { uhid, ...data, phone };
    } catch (e) {
      issues.push(`Row ${i + 2}: ${e.message}`);
      return null;
    }
  }).filter(Boolean);
  const existing = await db.query("SELECT uhid FROM patients WHERE uhid=ANY($1)", [rows.map((r) => r.uhid)]);
  for (const r of existing.rows) issues.push(`${r.uhid}: already exists`);
  if (!commit) {
    res.json({ count: rows.length, issues });
    return;
  }
  if (issues.length) fail(409, "Resolve import issues before saving: " + issues.slice(0, 4).join("; "));
  await transaction(async (c) => {
    for (const r of rows) {
      const q = await c.query("INSERT INTO patients(uhid,full_name,dob,age_years,sex,village) VALUES($1,$2,$3,$4,$5,$6) RETURNING id", [r.uhid, r.full_name, r.dob, r.age_years, r.sex, r.village]);
      if (r.phone) await c.query("INSERT INTO patient_phones(patient_id,mobile) VALUES($1,$2)", [q.rows[0].id, r.phone]);
    }
  });
  res.json({ imported: rows.length });
});
app.use("/api", (req, res) => res.status(404).json({ error: "Not found" }));
app.use((err, _req, res, _next) => {
  if (err.status) res.status(err.status).json({ error: err.message });
  else {
    console.error(err);
    res.status(500).json({ error: "Something went wrong. Please try again." });
  }
});
if (prod) {
  app.use(express.static(join(process.cwd(), "dist")));
  app.get(/.*/, (req, res) => res.sendFile(join(process.cwd(), "dist/index.html")));
}
app.listen(Number(process.env.PORT) || 3001, "0.0.0.0", () => console.log("Hospital API listening"));
