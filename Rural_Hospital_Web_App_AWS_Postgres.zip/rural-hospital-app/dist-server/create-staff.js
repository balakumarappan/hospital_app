// server/create-staff.ts
import bcrypt from "bcryptjs";

// server/db.ts
import "dotenv/config";
import pg from "pg";
var db = new pg.Pool({ connectionString: process.env.DATABASE_URL, max: 10, ssl: process.env.DATABASE_SSL === "true" ? { rejectUnauthorized: true } : void 0 });

// server/create-staff.ts
var [, , username, name, role] = process.argv;
var password = process.env.STAFF_PASSWORD;
if (!username || !name || !["admin", "reception"].includes(role) || !password || password.length < 12) {
  console.error('Set STAFF_PASSWORD (at least 12 characters), then: npm run staff:create -- USERNAME "Full Name" admin|reception');
  process.exit(1);
}
var hash = await bcrypt.hash(password, 12);
await db.query("INSERT INTO staff(username,name,role,password_hash) VALUES($1,$2,$3,$4) ON CONFLICT(username) DO UPDATE SET name=$2,role=$3,password_hash=$4,active=true", [username, name, role, hash]);
console.log("Staff login created");
await db.end();
