// server/migrate.ts
import { existsSync, readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { join } from "node:path";

// server/db.ts
import "dotenv/config";
import pg from "pg";
var db = new pg.Pool({ connectionString: process.env.DATABASE_URL, max: 10, ssl: process.env.DATABASE_SSL === "true" ? { rejectUnauthorized: true } : void 0 });

// server/migrate.ts
var local = fileURLToPath(new URL("./schema.sql", import.meta.url));
var path = existsSync(local) ? local : join(process.cwd(), "server/schema.sql");
await db.query(readFileSync(path, "utf8"));
console.log("Database schema ready");
await db.end();
